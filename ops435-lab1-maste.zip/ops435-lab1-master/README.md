# ops435-lab1
Repository for OPS435 Lab 1
Sample scripts for lab 1:
    sample.py - contains sections that will be found on most simple python script
                (1) shebang line
                (2) script level docstring
                (3) import section
                (4) function definition
                (5) main execution section
                    (a) access to command line arguments object
                    (b) code branching
                    (c) setting up list object
                    (d) looping
                    (e) counting
                    (f) run time error (exception) handling
                    (g) calling functions: built-ins and user defined
                    (h) objects: integer, string, list, dictionary
